package com.stackroute.moviecruiser.services;

import com.stackroute.moviecruiser.domain.User;
import com.stackroute.moviecruiser.exception.UserAlreadyExistsException;
import com.stackroute.moviecruiser.exception.UserNotFoundException;

public interface UserService {

	boolean saveUser(User user) throws UserAlreadyExistsException, UserNotFoundException;

	User findByUserIdAndPassword(String userId, String password) throws UserNotFoundException;

}
