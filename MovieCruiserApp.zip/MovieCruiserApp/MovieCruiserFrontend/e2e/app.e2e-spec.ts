import { browser, by, element } from 'protractor';
import { AppPage } from './app.po';
import { protractor } from 'protractor/built/ptor'

describe('movie-cruiser-frontend App', () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();    
  });

  it('should display title', () => {
    page.navigateTo();
    expect(browser.getTitle()).toEqual('Movie Cruiser Application');
  });

  it('should be redirected to /login route on openning the appliacaation', () => {
    expect(browser.getCurrentUrl()).toContain('/login');
  });

  it('should be redirected to /register route', () => {
    browser.element(by.css('.register-button')).click();
    expect(browser.getCurrentUrl()).toContain('/register');
  });

  it('should be able to register user', () => {
    browser.element(by.id('firstName')).sendKeys('Super User1');
    browser.element(by.id('lastName')).sendKeys('Super lastUser1');
    browser.element(by.id('userId')).sendKeys('Super User121');
    browser.element(by.id('password')).sendKeys('Super Userpass1');
    browser.element(by.css('.register-user')).click();
    //console.log(browser.getCurrentUrl());
    expect(browser.getCurrentUrl()).toContain('/login');
  });

  it('should be able to login user and navigate to /movies/popular', () => {
    browser.element(by.id('userId')).sendKeys('Super User121');
    browser.element(by.id('password')).sendKeys('Super Userpass1');
    browser.element(by.css('.login-user')).click();
    expect(browser.getCurrentUrl()).toContain('/movies/popular');
  });

  it('should be able to search for movies', () => {
    browser.element(by.css('.search-button')).click();
    expect(browser.getCurrentUrl()).toContain('/movies/search');
    browser.element(by.id('search-button-input')).sendKeys('Super');
    browser.element(by.id('search-button-input')).sendKeys(protractor.Key.ENTER);
    const searchItems = element.all(by.css('.tooltip'));
    expect(searchItems.count()).toBe(20);
    for(let i=0;i<1;i+=1){
      expect(searchItems.get(i).getText()).toContain('Super');
    }
  });

  it('should be able to add movie in the watch list',async ()=>{
    browser.manage().window().maximize();
    browser.driver.sleep(1000);
    const searchItems = element.all(by.css('.movie-thumbnail'));
    expect(searchItems.count()).toBe(20);
    searchItems.get(0).click();
    browser.element(by.css('.movie-button')).click();
  });
  
});
