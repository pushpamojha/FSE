Demo application for MovieCruiser Server
