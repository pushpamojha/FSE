package com.stackroute.qna.auth.repositories;


import org.springframework.data.jpa.repository.JpaRepository;

import com.stackroute.qna.auth.domain.User;

public interface UserRepository extends JpaRepository<User, String>  {
	
	User findByUserIdAndPassword(String userId,String password);

	//Optional<User> findById(String userId);

}
