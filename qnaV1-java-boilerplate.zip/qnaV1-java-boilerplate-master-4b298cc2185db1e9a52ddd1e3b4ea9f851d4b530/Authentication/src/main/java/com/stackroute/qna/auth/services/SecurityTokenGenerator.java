package com.stackroute.qna.auth.services;

import java.util.Map;

import com.stackroute.qna.auth.domain.User;

public interface SecurityTokenGenerator {
	Map<String, String> generateToken(User user);
}
