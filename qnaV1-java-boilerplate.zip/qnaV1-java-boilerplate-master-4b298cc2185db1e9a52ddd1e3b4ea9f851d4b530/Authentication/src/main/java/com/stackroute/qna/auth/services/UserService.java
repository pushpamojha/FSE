package com.stackroute.qna.auth.services;

import com.stackroute.qna.auth.domain.User;
import com.stackroute.qna.auth.exception.UserAlreadyExistsException;
import com.stackroute.qna.auth.exception.UserNotFoundException;

public interface UserService {

	boolean saveUser(User user) throws UserAlreadyExistsException, UserNotFoundException;

	User findByUserIdAndPassword(String userId, String password) throws UserNotFoundException;

}
