import { browser, by, element } from 'protractor';
import { protractor } from 'protractor';

import { AppPage } from "./app.po";


describe("question-n-answers App", () => {
  let page: AppPage;

  beforeEach(() => {
    page = new AppPage();
  });

  it('should display Title', () => {
    page.navigateTo();
    expect(browser.getTitle()).toEqual('QnA Application');
  });

  it('should be redirected to /login route on opening the application', () => {
    expect(browser.getCurrentUrl()).toContain('/login')
  });

  it('should be redirected to /register route', () => {
    browser.element(by.css('.register-button')).click()
    expect(browser.getCurrentUrl()).toContain('/register')
  });

  it('should be able to register user', () => {    
    browser.element(by.id('firstName')).sendKeys('Pushpam');
    browser.element(by.id('lastName')).sendKeys('Ojha');
    browser.element(by.id('userId')).sendKeys('pushpam.ojha@cognizant.com');
    browser.element(by.id('password')).sendKeys('123456');
    browser.element(by.id('confirmPasswordControl')).sendKeys('123456');
    browser.element(by.css('.register-user')).click();
    browser.driver.sleep(5999);
    expect(browser.getCurrentUrl()).toContain('/login')
  });

  it('should be able to login user and navigate to Topics', () => {
    browser.element(by.id('userId')).sendKeys('pushpam.ojha@cognizant.com');
    browser.element(by.id('password')).sendKeys('123456');
    browser.element(by.css('.login-user')).click()
    expect(browser.getCurrentUrl()).toContain('/qna/dashboard');
  });

  it('should be able to view questions under a topic', async () => {
    browser.driver.manage().window().maximize();
    browser.driver.sleep(3000);
    const topics = element.all(by.css('.topic-container'));
    expect(topics.count()).toBeGreaterThan(0);
    topics.get(0).click();
    browser.element(by.css('.view-topic-details')).click();
  });

  it('should be able to post question', async () => {
    browser.driver.sleep(3000);
    browser.element(by.id('question-field')).sendKeys('e2e Question1');
    browser.element(by.id('question-button')).click();
    browser.driver.sleep(1500);
    browser.element(by.id('question-field')).sendKeys('e2e Question2');
    browser.element(by.id('question-button')).click();
    const questions = element.all(by.css('.question-card'));
    expect(questions.count()).toBeGreaterThan(0);
  });

  it('should be able to delete a question', async () => {
    const question = element.all(by.css('.question-card'));
    expect(question.count()).toEqual(2);
    browser.driver.sleep(3000);
    question.get(0).click();
    browser.element(by.css('.delete-question')).click();
    browser.driver.sleep(3000);
    const question2 = element.all(by.css('.question-card'));
    expect(question2.count()).toEqual(1);
  });

  it('should be able to view comments under a question', async () => {
      browser.driver.sleep(3000);
      const question = element.all(by.css('.question-card'));
      expect(question.count()).toBeGreaterThan(0);
      question.get(0).click();
      browser.element(by.css('.view-comments')).click();
  });

  it('should be able to post a comment', async () => {
    browser.driver.sleep(3000);
    browser.element(by.id('comment-field')).sendKeys('e2e Comment');
    browser.element(by.id('comment-button')).click();
    const comments = element.all(by.css('.comment-card'));
    expect(comments.count()).toBeGreaterThan(0);
  });

  it('should be able to view delete a comment', async () => {
    const comment = element.all(by.css('.comment-card'));
    expect(comment.count()).toBeGreaterThan(0);
    comment.get(0).click();
    browser.element(by.css('.delete-comment')).click();
    const comment2 = element.all(by.css('.comment-card'));
    expect(comment.count()).toEqual(0);
  });
  



});
