import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { AuthenticationService } from './../auth-service.service';
import { User } from './../user'
import { QnaUtility } from '../../qna/qna-utility';
import { CheckPasswordDirective } from './check-password';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
 
  user: User;
  errMsg: string;

  constructor(private authService: AuthenticationService, private router: Router, private qUtil: QnaUtility) {
    this.user = new User();
  }

  ngOnInit() {
  }

  registerUser() {
    console.log("Register user:", this.user.userId, this.user.firstName);
    console.log("new user", this.user);
    this.authService.registerUser(this.user).subscribe(
      (data) => {
        console.log("user data", data);
        this.router.navigate(['/login']);
      },
      (error) => {console.log("error : " , error);
      this.qUtil.snackBarErrorMessage(error,2000)
      this.errMsg = error.error.message;
     }
    );
  }

 /* resetInput(f) {
    console.log("Inside reset", f);
    f.resetForm({});
  }*/

}

