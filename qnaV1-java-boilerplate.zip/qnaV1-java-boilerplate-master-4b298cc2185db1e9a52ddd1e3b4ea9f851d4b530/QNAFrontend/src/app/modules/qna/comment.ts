import { Question } from './question';

export interface Comment{
    id: string;
    description: string;
    createdDate: string;
    question: Question;
}