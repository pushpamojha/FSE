import { Component, OnInit } from '@angular/core';
import { Location } from '@angular/common';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { HttpErrorResponse } from '@angular/common/http';

import { TopicService } from './../../topic.service';
import { Question } from './../../question';
import { Comment } from './../../comment';
import { Topic } from './../../topic';

@Component({
  selector: 'qna-comment',
  templateUrl: './comment.component.html',
  styleUrls: ['./comment.component.css']
})
export class CommentComponent implements OnInit {

  comments: Array<Comment>;
  private question_id: string;

  postedComment: string;

  constructor(private qnaService: TopicService, private router: ActivatedRoute, private location: Location, private snackBar: MatSnackBar) {
    this.comments = [];
  }

  ngOnInit() {
    this.router.params.subscribe((params: Params) => {
      console.log(params);
      this.question_id = params['question_id'];
    });
    this.qnaService.getCommentsByQuestionId(this.question_id).subscribe((comments) => {
      console.log(comments);
      this.comments.push(...comments);
    });
  }

  backClicked() {
    this.location.back();
  }

  postComment() {
    //const topic: Topic = { id: `${this.topic_id}`, name: "", description: "" };
    const question: Question = { id: `${this.question_id}`, description: "", createdDate: null, topic: null };
    const commentToBePosted = { id: "", description: `${this.postedComment}`, createdDate: null, question: question };
    this.qnaService.postCommentToSave(commentToBePosted).subscribe((retComment: Comment) => {
      commentToBePosted.id = retComment.id;
      commentToBePosted.createdDate = retComment.createdDate;
      this.snackBar.open('Comment added successfully', '', { duration: 5000 });
      this.postedComment = '';
    },
      (error) => {
        this.snackBar.open(error.message, '', { duration: 5000 });
      });

    console.log(commentToBePosted);
    this.comments.splice(0, 0, commentToBePosted);
  }

  deleteComment(comment_id: string) {
    for (var i = 0; i < this.comments.length; i++) {
      if (this.comments[i].id == comment_id) {
        this.comments.splice(i, 1);
      }
    }

    this.qnaService.deleteComment(comment_id).subscribe(() => {
      console.log("deleted");
      this.snackBar.open('Comment deleted successfully', '', { duration: 5000 });
    });
  }

}
