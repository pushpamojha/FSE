import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';

import { Topic } from '../../topic';
import { TopicService } from '../../topic.service';
import { HttpErrorResponse } from '@angular/common/http';
import {QnaUtility} from '../../qna-utility';

@Component({
  selector: 'topic-container',
  templateUrl: './container.component.html',
  styleUrls: ['./container.component.css']
})
export class ContainerComponent implements OnInit {

  @Input()
  topics: Array<Topic>;

  constructor(private topicService: TopicService, private activeRoute: ActivatedRoute, 
    private snackBar: MatSnackBar, private mUtil: QnaUtility) {

  }

  ngOnInit() {


  }

}
