
import { Component, OnInit, Input } from '@angular/core';
import { Location } from '@angular/common';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { HttpErrorResponse } from '@angular/common/http';

import { TopicService } from './../../topic.service';
import { Question } from './../../question';
import { Topic } from './../../topic';

@Component({
  selector: 'qna-question',
  templateUrl: './question.component.html',
  styleUrls: ['./question.component.css']
})
export class QuestionComponent implements OnInit {

  questions: Array<Question>;
  private topic_id: string;
  private title: string;
  private description: string;

  postedQuestion: string;

  constructor(private qnaService: TopicService, private router: ActivatedRoute, private location: Location, private snackBar: MatSnackBar) {
    this.questions = [];
  }

  ngOnInit() {
    this.router.params.subscribe((params: Params) => {
      console.log(params);
      this.topic_id = params['topic_id'];
      this.title = params['title'];
      this.description = params['description'];
    });
    this.qnaService.getQuestionsByTopicId(this.topic_id).subscribe((questions) => {
      console.log(questions);
      this.questions.push(...questions);
    });
  }

  backClicked() {
    this.location.back();
  }

  postQuestion() {
    const topic: Topic = { id: `${this.topic_id}`, title: "", description: ""};
    const questionTobePosted: Question = { id: "", description: `${this.postedQuestion}`, createdDate: null, topic: topic }
    this.qnaService.postQuestionToSave(questionTobePosted).subscribe((retQuestion: Question) => {
      questionTobePosted.id = retQuestion.id;
      questionTobePosted.createdDate = retQuestion.createdDate;
      this.snackBar.open('Question added successfully', '', { duration: 5000 });
      this.postedQuestion = '';
    }, (error) => {
      this.snackBar.open(error.message, '', { duration: 5000 });
    });

    console.log(questionTobePosted);
    this.questions.splice(0, 0, questionTobePosted);

  }

  deleteQuestion(question_id: string) {
    for (var i = 0; i < this.questions.length; i++) {
      if (this.questions[i].id == question_id) {
        this.questions.splice(i, 1);
      }
    }

    this.qnaService.deleteQuestion(question_id).subscribe(() => {
      console.log("deleted");
      this.snackBar.open('Question deleted successfully', '', { duration: 5000 });
    });
  }

}
