import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';


import { Topic } from '../../topic';
import { TopicService } from '../../topic.service';
//import { MovieDialogComponent } from '../movie-dialog/movie-dialog.component';



@Component({
  selector: 'topic-thumbnail',
  templateUrl: './thumbnail.component.html',
  styleUrls: ['./thumbnail.component.css']
})

export class ThumbnailComponent implements OnInit {

  @Input()
  topic: Topic;

 /* @Input()
  useWatchlistApi: boolean;

  @Output()
  addMovie = new EventEmitter();

  @Output()
  deleteMovie = new EventEmitter();*/


  constructor(private topicService: TopicService, private snackBar: MatSnackBar,private matDlg: MatDialog) {
  }

  ngOnInit() {
  }

  /*addToWatchlist() {
    this.addMovie.emit(this.movie);    
  }

  deletMovieFromWatchlist(){
    this.deleteMovie.emit(this.movie);    
  }

  updateWatchlist(actionType){
    console.log('movie is getting updated');
    let dialogRef = this.matDlg.open(MovieDialogComponent,
    {
      width:"400px",
      data: {obj: this.movie,actionType: actionType}
    });
    console.log("open the dialog");
    dialogRef.afterClosed().subscribe((results)=>{
      console.log("this dialog was closed");
    })
  }*/
}
