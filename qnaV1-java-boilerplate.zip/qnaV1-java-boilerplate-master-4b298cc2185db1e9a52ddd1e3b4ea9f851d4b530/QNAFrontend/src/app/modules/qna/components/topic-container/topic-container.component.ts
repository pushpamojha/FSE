import { Component, OnInit } from '@angular/core';

import { ActivatedRoute } from '@angular/router'

import { Topic } from '../../topic';
import { TopicService } from '../../topic.service';
import { QnaUtility } from '../../qna-utility';


@Component({
  selector: 'topic-dashboard-container',
  templateUrl: './topic-container.component.html',
  styleUrls: ['./topic-container.component.css']
})
export class TopicContainerComponent implements OnInit {

  topics: Array<Topic>;
  //movieType: string;

  constructor(private topicService: TopicService, private activeRoute: ActivatedRoute,private qUtil: QnaUtility) { 
    this.topics=[];    
    this.activeRoute.data.subscribe(data => {
      //this.movieType = data.movieType
    });
  }

  ngOnInit() {  
    
    //this.movieService.getMovies(this.movieType)
    this.topicService.getTopics()
    .subscribe((topics) => {
      this.topics.push(...topics);
      },
      (error) => {this.qUtil.snackBarErrorMessage(error,2000)});  
  }

}
