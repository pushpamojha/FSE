import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

 
import { ContainerComponent } from './components/container/container.component';
import { TopicContainerComponent } from './components/topic-container/topic-container.component';
import { AuthguardService } from './../../authguard.service';
import { QuestionComponent } from './components/question/question.component';
import { CommentComponent } from './components/comment/comment.component';

const qnaRoutes: Routes = [{
    path: 'qna',
    children: [
        {
            path: '',
            redirectTo: '/qna/dashboard',
            pathMatch: 'full',
            canActivate: [AuthguardService]
        },
        {
            path: 'dashboard',
            component: TopicContainerComponent,
            canActivate: [AuthguardService]
          
        },
        {
            path: 'topic-details/:topic_id/:title/:description',
            component: QuestionComponent,
            canActivate:[AuthguardService]
        },
        {
            path: 'question-details/:question_id',
            component: CommentComponent,
            canActivate:[AuthguardService]
        }
    ]
}]

@NgModule({
imports: [
    RouterModule.forChild(qnaRoutes)
],
declarations: [],
exports: [RouterModule],
providers: []
})

export class QnaRouterModule {}