import { Topic } from './topic';

export interface Question {
    id: string;
    description: string;
    createdDate: string;
    topic: Topic;
}