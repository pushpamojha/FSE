import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule,HTTP_INTERCEPTORS } from '@angular/common/http';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialogModule } from '@angular/material/dialog';
import { FormsModule } from '@angular/forms';
import { MatInputModule } from '@angular/material/input';
import { ThumbnailComponent } from './components/thumbnail/thumbnail.component';
import { TopicService } from './topic.service';
import { ContainerComponent } from './components/container/container.component';
import { QnaRouterModule } from './qna-router.module';
import { TopicContainerComponent } from './components/topic-container/topic-container.component';
import { QnaUtility } from './qna-utility';
import { TokenInterceptor } from './interceptor.service';
import { QuestionComponent } from './components/question/question.component';
import { CommentComponent } from './components/comment/comment.component';


@NgModule({
  imports: [
    HttpClientModule,
    CommonModule,
    MatCardModule,
    MatButtonModule,
    MatSnackBarModule,
    MatDialogModule,
    FormsModule,
    MatInputModule,
    QnaRouterModule
  ],
  declarations: [
    ThumbnailComponent,
    ContainerComponent,
    TopicContainerComponent,
    QuestionComponent,
    CommentComponent
  ],
  exports: [
    ContainerComponent,
    QnaRouterModule
  ],
  providers: [
    TopicService,{ provide: HTTP_INTERCEPTORS, useClass: TokenInterceptor, multi: true },
    QnaUtility
  ]
})
export class TopicModule { }
