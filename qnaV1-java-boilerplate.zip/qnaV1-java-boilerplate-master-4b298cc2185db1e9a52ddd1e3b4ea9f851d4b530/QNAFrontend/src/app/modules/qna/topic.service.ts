import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators/map';
import { Observable } from 'rxjs/Observable';
import { retry } from 'rxjs/operators';
import { Topic } from './topic';
import { Question } from './question';
import { Comment } from './comment'

@Injectable()
export class TopicService {


  endPointUrl: string;

  constructor(private http: HttpClient) {
    this.endPointUrl = 'http://localhost:8080/api/v1/qnaservice';
  }

  getTopics(): Observable<Array<Topic>> {
    return this.http.get<Array<Topic>>(`${this.endPointUrl}/dashboard`).pipe(
      retry(3)
    );
  }

  getQuestionsByTopicId(topic_id: string): Observable<Array<Question>> {
    const questionEndpointUrl = `${this.endPointUrl}/questions/${topic_id}`;
    const result = this.http.get<Array<Question>>(questionEndpointUrl).pipe(
      retry(3)
    );
    return result;
  }

  postQuestionToSave(question) {
    const questionPostUrl = `${this.endPointUrl}/question`;
    console.log("questionPostUrl: ", questionPostUrl );
    return this.http.post(questionPostUrl, question);
  }

  deleteQuestion(question_id: string) {
    const questionDeleteUrl = `${this.endPointUrl}/question/${question_id}`
    return this.http.delete(questionDeleteUrl, { responseType: 'text' });
  }

  getCommentsByQuestionId(question_id: string): Observable<Array<Comment>> {
    const commentEndpointUrl = `${this.endPointUrl}/comments/${question_id}`;
    const result = this.http.get<Array<Comment>>(commentEndpointUrl).pipe(
      retry(3)
    );
    return result;
  }

  postCommentToSave(comment) {
    const commentPostUrl = `${this.endPointUrl}/comment`;
    return this.http.post(commentPostUrl, comment);
  }

  deleteComment(comment_id: string) {
    const commentDeleteUrl = `${this.endPointUrl}/comment/${comment_id}`
    return this.http.delete(commentDeleteUrl, { responseType: 'text' });
  }


}
