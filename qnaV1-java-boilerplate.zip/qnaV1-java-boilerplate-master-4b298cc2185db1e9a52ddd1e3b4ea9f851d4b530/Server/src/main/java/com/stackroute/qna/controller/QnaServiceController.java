package com.stackroute.qna.controller;

import java.util.List;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stackroute.qna.domain.Comment;
import com.stackroute.qna.domain.Question;
import com.stackroute.qna.domain.Topic;
import com.stackroute.qna.exception.CommentNotFoundException;
import com.stackroute.qna.exception.QuestionNotFoundException;
import com.stackroute.qna.service.QnaService;

import io.jsonwebtoken.Jwts;

@CrossOrigin(origins = {"http://localhost:4200","http://localhost:49152"}, maxAge = -1)
@RestController
@RequestMapping(path = "/api/v1/qnaservice")
public class QnaServiceController {

	private QnaService qnaService;

	@Autowired
	public QnaServiceController(final QnaService qnaService) {
		this.qnaService = qnaService;
	}
	

	@GetMapping("dashboard")
	public ResponseEntity<List<Topic>> fetchTopics(ServletRequest req,ServletResponse res) {
		HttpServletRequest request = (HttpServletRequest)req;
		String authHeader = request.getHeader("authorization");
		String token = authHeader.substring(7);
		String userId = Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody().getSubject();

		return new ResponseEntity<List<Topic>>(qnaService.getAllTopics(), HttpStatus.OK);
	}
	
	@GetMapping(path = "/questions/{topicId}")
	public ResponseEntity<?> fetchQuestionsByTopic(@PathVariable("topicId") int topicId) {
		System.out.println("topic_id:-"+topicId);
		ResponseEntity<?> responseEntity = null;
		try {
			responseEntity = new ResponseEntity<List<Question>>(qnaService.getQuestionsOnTopic(topicId), HttpStatus.OK);
		} catch (QuestionNotFoundException qnfe) {
			responseEntity = new ResponseEntity<String>("{\"message\":\"" + qnfe.getMessage() + "\"}",
					HttpStatus.NOT_FOUND);
		}
		return responseEntity;

	}

	@GetMapping(path = "/comments/{questionId}")
	public ResponseEntity<?> fetchCommentsByQuestion(@PathVariable("questionId") int questionId) {
		ResponseEntity<?> responseEntity = null;
		try {
			responseEntity = new ResponseEntity<List<Comment>>(qnaService.getCommentOnQuestion(questionId),
					HttpStatus.OK);
		} catch (CommentNotFoundException cnfe) {
			responseEntity = new ResponseEntity<String>("{\"message\":\"" + cnfe.getMessage() + "\"}",
					HttpStatus.NOT_FOUND);
		}
		return responseEntity;

	}
	
	@PostMapping(path="/question")
	public ResponseEntity<?> saveQuestion(@RequestBody Question question, HttpServletRequest request,
			HttpServletResponse response)
	{
		String authHeader = request.getHeader("authorization");
		String token = authHeader.substring(7);
		String userId = Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody().getSubject();
		
		question.setUserId(userId);
		
		ResponseEntity<?> responseEntity = null;
		qnaService.saveQuestion(question);
		responseEntity = new ResponseEntity<Question>(question,HttpStatus.CREATED);
		return responseEntity;
	}
	
	@PostMapping(path="/comment")
	public ResponseEntity<?> saveComment(@RequestBody Comment comment, HttpServletRequest request,
			HttpServletResponse response)
	{
		String authHeader = request.getHeader("authorization");
		String token = authHeader.substring(7);
		String userId = Jwts.parser().setSigningKey("secretkey").parseClaimsJws(token).getBody().getSubject();
		
		comment.setUserId(userId);
		
		ResponseEntity<?> responseEntity = null;
		qnaService.saveComment(comment);
		responseEntity = new ResponseEntity<Comment>(comment,HttpStatus.CREATED);
		return responseEntity;
	}
	
	@DeleteMapping(path="question/{id}")
	public ResponseEntity<?> deleteQuestion(@PathVariable("id") int id)
	{
		ResponseEntity<?> responseEntity = null;
		try {
			qnaService.deleteQuestion(id);
			responseEntity = new ResponseEntity<String>("Question deleted successfully",HttpStatus.OK);
		} catch (QuestionNotFoundException qnfe) {
			responseEntity = new ResponseEntity<String>("{\"message\":\"" + qnfe.getMessage() + "\"}",
					HttpStatus.NOT_FOUND);
		}
		return responseEntity;
	}
	
	@DeleteMapping(path="comment/{id}")
	public ResponseEntity<?> deleteComment(@PathVariable("id") int id)
	{
		ResponseEntity<?> responseEntity = null;
		try {
			qnaService.deleteComment(id);
			responseEntity = new ResponseEntity<String>("Comment deleted successfully",HttpStatus.OK);
		} catch (CommentNotFoundException qnfe) {
			responseEntity = new ResponseEntity<String>("{\"message\":\"" + qnfe.getMessage() + "\"}",
					HttpStatus.NOT_FOUND);
		}
		return responseEntity;
	}
	

}
