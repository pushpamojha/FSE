package com.stackroute.qna.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonProperty;

@Entity
@Table(name = "topic")
public class Topic {

	@Id
	@Column(name = "id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	
	@JsonProperty("title")
	@Column(name = "title")
	private String title;
	
	
	@JsonProperty("description")
	@Column(name = "description")
	private String description;
	

	public Topic() {
	}

	public Topic(int id, String title, String description) {
		this.id = id;
		this.title = title;
		this.description = description;
	}

	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@JsonProperty("title")
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}	

	@Override
	public String toString() {
		return "Topic [id=" + id + ", title=" + title + ", description=" + description + "]";
	}

}
