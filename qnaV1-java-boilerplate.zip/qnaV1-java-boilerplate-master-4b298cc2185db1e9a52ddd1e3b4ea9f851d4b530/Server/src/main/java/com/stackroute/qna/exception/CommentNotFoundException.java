package com.stackroute.qna.exception;

public class CommentNotFoundException extends Exception {
	String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public CommentNotFoundException(String message) {
		super();
		this.message = message;
	}

	@Override
	public String toString() {
		return "CommentNotFoundException [message=" + message + "]";
	}
}
