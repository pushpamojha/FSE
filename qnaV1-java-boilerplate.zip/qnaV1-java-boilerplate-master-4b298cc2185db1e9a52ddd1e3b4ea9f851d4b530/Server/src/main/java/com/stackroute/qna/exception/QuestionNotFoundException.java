package com.stackroute.qna.exception;

public class QuestionNotFoundException extends Exception {
	String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public QuestionNotFoundException(String message) {
		super();
		this.message = message;
	}

	@Override
	public String toString() {
		return "QuestionNotFoundException [message=" + message + "]";
	}
}
