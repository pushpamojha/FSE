package com.stackroute.qna.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.stackroute.qna.domain.Topic;

public interface TopicRepository extends JpaRepository<Topic, Integer> {

}
