package com.stackroute.qna.service;

import java.util.List;

import com.stackroute.qna.domain.Comment;
import com.stackroute.qna.domain.Question;
import com.stackroute.qna.domain.Topic;
import com.stackroute.qna.exception.CommentNotFoundException;
import com.stackroute.qna.exception.QuestionNotFoundException;

public interface QnaService {
	
	List<Topic> getAllTopics();
	
	boolean saveQuestion(Question question);

	List<Question> getQuestionsOnTopic(Integer topicId) throws QuestionNotFoundException;
	
	boolean deleteQuestion(Integer id) throws QuestionNotFoundException;
	
	boolean saveComment(Comment comment);
	
	List<Comment> getCommentOnQuestion(Integer questionId) throws CommentNotFoundException;
	
	boolean deleteComment(Integer id) throws CommentNotFoundException;
}
