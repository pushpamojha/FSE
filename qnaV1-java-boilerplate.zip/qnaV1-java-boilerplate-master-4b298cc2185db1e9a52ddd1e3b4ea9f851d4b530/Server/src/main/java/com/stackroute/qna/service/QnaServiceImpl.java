package com.stackroute.qna.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stackroute.qna.domain.Comment;
import com.stackroute.qna.domain.Question;
import com.stackroute.qna.domain.Topic;
import com.stackroute.qna.exception.CommentNotFoundException;
import com.stackroute.qna.exception.QuestionNotFoundException;
import com.stackroute.qna.repository.CommentRepository;
import com.stackroute.qna.repository.QuestionRepository;
import com.stackroute.qna.repository.TopicRepository;

@Service
public class QnaServiceImpl implements QnaService {

	private final transient TopicRepository topicRepository;
	private final transient QuestionRepository questionRepository;
	private final transient CommentRepository commentRepository;

	@Autowired
	public QnaServiceImpl(TopicRepository topicRepository, QuestionRepository questionRepository,
			CommentRepository commentRepository) {
		this.topicRepository = topicRepository;
		this.questionRepository = questionRepository;
		this.commentRepository = commentRepository;
	}

	@Override
	public List<Topic> getAllTopics() {
		return topicRepository.findAll();
	}

	@Override
	public boolean saveQuestion(Question question) {
		questionRepository.save(question);
		questionRepository.flush();
		return true;
	}

	@Override
	public List<Question> getQuestionsOnTopic(Integer topicId) throws QuestionNotFoundException {
		List<Question> questions=questionRepository.findByTopicIdOrderByIdDesc(topicId);
		if(null == questions) {
			throw new QuestionNotFoundException("No question found for the topic selected");
		}
		return questions;
	}

	@Override
	public boolean deleteQuestion(Integer id) throws QuestionNotFoundException{
		final Question question = questionRepository.findById(id).orElse(null);
		if (question == null) {
			throw new QuestionNotFoundException("Could not delete Question, Question not found!");
		}		
		questionRepository.deleteById(id);
		return true;
	}

	@Override
	public boolean saveComment(Comment comment) {
		commentRepository.save(comment);
		commentRepository.flush();
		return true;
	}

	@Override
	public List<Comment> getCommentOnQuestion(Integer questionId) throws CommentNotFoundException {
		List<Comment> comments=commentRepository.findByQuestionIdOrderByIdDesc(questionId);
		if(null == comments) {
			throw new CommentNotFoundException("No comment found for the question selected");
		}
		return comments;
	}

	@Override
	public boolean deleteComment(Integer id) throws CommentNotFoundException {
		final Comment comment = commentRepository.findById(id).orElse(null);
		if (comment == null) {
			throw new CommentNotFoundException("Could not delete Comment, Comment not found!");
		}		
		commentRepository.deleteById(id);
		return true;
	}

}
