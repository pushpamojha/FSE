package com.stackroute.qna.controller;

import java.util.ArrayList;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.stackroute.qna.domain.Comment;
import com.stackroute.qna.domain.Question;
import com.stackroute.qna.domain.Topic;
import com.stackroute.qna.service.QnaServiceImpl;

import static org.mockito.Mockito.times;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@WebMvcTest(controllers = QnaServiceController.class)
public class QnaServiceControllerTest {

	private transient MockMvc mockMvc;

	@MockBean
	private transient QnaServiceImpl service;

	@Autowired
	private WebApplicationContext webApplicationContext;

	static transient Topic topic;
	static transient Comment comment;
	static transient Question question;
	static List<Topic> topics;
	static List<Comment> comments;
	static List<Question> questions;
	static String token;

	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
		topics = new ArrayList<>();
		comments = new ArrayList<>();
		questions = new ArrayList<>();
		topic = new Topic(1, "Topic1", "Weather");
		question = new Question("question1");
		question.setId(1);
		question.setTopic(topic);
		comment = new Comment("comment1");
		comment.setId(1);
		comment.setQuestion(question);
		topics.add(topic);
		questions.add(question);
		comments.add(comment);
		token = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJwdXNocGFtLm9qaGFAZ21haWwuY29tIiwiaWF0IjoxNTQwMzk2MzUxfQ.McLLz9pJKV9lfRbrt9VDNKxKDloU5hw828srdpczNJM";
	}

	@Test
	public void testGetAllTopics() throws JsonProcessingException, Exception {
		Mockito.when(service.getAllTopics()).thenReturn(topics);
		mockMvc.perform(get("/api/v1/qnaservice/dashboard").contentType(MediaType.APPLICATION_JSON).header("authorization",
				"Bearer " + token)).andExpect(status().isOk());
		Mockito.verify(service, times(1)).getAllTopics();
		Mockito.verifyNoMoreInteractions(service);
	}

	@Test
	public void testGetQuestionsByTopic() throws JsonProcessingException, Exception {
		Mockito.when(service.getQuestionsOnTopic(topic.getId())).thenReturn(questions);
		mockMvc.perform(get("/api/v1/qnaservice/questions/{topicId}", topic.getId())
				.contentType(MediaType.APPLICATION_JSON).header("authorization", "Bearer " + token))
				.andExpect(status().isOk());
		Mockito.verify(service, times(1)).getQuestionsOnTopic(topic.getId());
		Mockito.verifyNoMoreInteractions(service);
	}

	@Test
	public void testGetCommentsByQuestion() throws JsonProcessingException, Exception {
		Mockito.when(service.getCommentOnQuestion(question.getId())).thenReturn(comments);
		mockMvc.perform(get("/api/v1/qnaservice/comments/{questionId}", question.getId())
				.contentType(MediaType.APPLICATION_JSON).header("authorization", "Bearer " + token))
				.andExpect(status().isOk());
		Mockito.verify(service, times(1)).getCommentOnQuestion(question.getId());
		Mockito.verifyNoMoreInteractions(service);
	}

	@Test
	public void testSaveQuestion() throws JsonProcessingException, Exception {
		Mockito.when(service.saveQuestion(question)).thenReturn(true);
		mockMvc.perform(
				post("/api/v1/qnaservice/question", topic.getId()).header("authorization", "Bearer " + token)
						.contentType(MediaType.APPLICATION_JSON).content(jsonToString(question)))
				.andExpect(status().isCreated());
		Mockito.verify(service, times(1)).saveQuestion(Mockito.any(Question.class));
		Mockito.verifyNoMoreInteractions(service);
	}

	@Test
	public void testSaveComment() throws JsonProcessingException, Exception {
		Mockito.when(service.saveComment(comment)).thenReturn(true);
		mockMvc.perform(post("/api/v1/qnaservice/comment", question.getId())
				.header("authorization", "Bearer " + token).contentType(MediaType.APPLICATION_JSON)
				.content(jsonToString(comment))).andExpect(status().isCreated());
		Mockito.verify(service, times(1)).saveComment(Mockito.any(Comment.class));
		Mockito.verifyNoMoreInteractions(service);
	}

	@Test
	public void testDeleteQuestion() throws JsonProcessingException, Exception {
		Mockito.when(service.deleteQuestion(question.getId())).thenReturn(true);
		mockMvc.perform(
				delete("/api/v1/qnaservice/question/{id}", question.getId()).header("authorization", "Bearer " + token))
				.andExpect(status().isOk());
		Mockito.verify(service, times(1)).deleteQuestion(question.getId());
		Mockito.verifyNoMoreInteractions(service);
	}

	@Test
	public void testDeleteComment() throws JsonProcessingException, Exception {
		Mockito.when(service.deleteComment(comment.getId())).thenReturn(true);		
		mockMvc.perform(
				delete("/api/v1/qnaservice/comment/{id}", comment.getId()).header("authorization", "Bearer " + token))
				.andExpect(status().isOk());
		Mockito.verify(service, times(1)).deleteComment(comment.getId());
		Mockito.verifyNoMoreInteractions(service);
	}

	private static String jsonToString(final Object obj) throws JsonProcessingException {
		String result;
		try {
			final ObjectMapper mapper = new ObjectMapper();
			final String jsonContent = mapper.writeValueAsString(obj);
			result = jsonContent;
		} catch (JsonProcessingException e) {
			result = "Json Processing error";
		}
		return result;
	}

}
