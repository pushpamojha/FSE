package com.stackroute.qna.repository;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.stackroute.qna.domain.Comment;
import com.stackroute.qna.domain.Question;
import com.stackroute.qna.domain.Topic;

@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
@Transactional
public class QnaRepoTest {

	@Autowired
	private transient TopicRepository topicRepository;
	@Autowired
	private transient QuestionRepository questionRepository;
	@Autowired
	private transient CommentRepository commentRepository;

	public void setTopicRepository(TopicRepository topicRepository) {
		this.topicRepository = topicRepository;
	}

	public void setQuestionRepository(QuestionRepository questionRepository) {
		this.questionRepository = questionRepository;
	}

	public void setCommentRepository(CommentRepository commentRepository) {
		this.commentRepository = commentRepository;
	}

	private Topic topic;

	@Before
	public void setBefore() {

		if (topic == null) {
			Optional<Topic> t = topicRepository.findById(5);
			if (!t.isPresent()) {
				topic = topicRepository.save(new Topic(5, "Test Topic ", "Test Topic Description"));
				topicRepository.flush();
			} else {
				topic = t.get();
			}
		}

	}

	@Test
	public void testFindAllTopics() throws Exception {
		List<Topic> topics = topicRepository.findAll();
		assertThat(topics.size()).isGreaterThan(0);
	}

	@Test
	public void testSaveQuestion() {
		Question q = new Question("Test Question 1");
		q.setTopic(topic);
		Question q1 = questionRepository.save(q);
		questionRepository.flush();
		System.out.println(q1.getId());
		assertThat(q1.getId()).isNotNull();
		questionRepository.delete(q1);
	}

	@Test
	public void testGetQuestionByTopicId() {
		Question q = new Question("Test Question 2");
		q.setTopic(topic);
		questionRepository.save(q);
		questionRepository.flush();
		List<Question> lq = questionRepository.findByTopicIdOrderByIdDesc(topic.getId());
		assertThat(lq).isNotEmpty();
		questionRepository.delete(q);
	}

	@Test
	public void testDeleteQuestion() {
		Question q = new Question("Test Question 3");
		q.setTopic(topic);
		Question q1 = questionRepository.save(q);
		questionRepository.flush();
		int id = q1.getId();
		questionRepository.delete(q1);
		Optional<Question> oq = questionRepository.findById(id);
		assertThat(oq).isEqualTo(Optional.empty());
	}

	@Test
	public void testSaveComment() {
		Question q = new Question("Test Question 4");
		q.setTopic(topic);
		Question q1 = questionRepository.save(q);
		questionRepository.flush();
		Comment c = new Comment("Test Comment 1");
		c.setQuestion(q1);
		Comment c1 = commentRepository.save(c);
		commentRepository.flush();
		assertThat(c1.getId()).isNotNull();
		
	}

	@Test
	public void testGetCommentByQuestionId() {
		Question q = new Question("Test Question 4");
		q.setTopic(topic);
		Question q1 = questionRepository.save(q);
		questionRepository.flush();
		Comment c = new Comment("Test Comment 2");
		c.setQuestion(q1);
		commentRepository.save(c);
		commentRepository.flush();

		List<Comment> lc = commentRepository.findByQuestionIdOrderByIdDesc(q1.getId());
		assertThat(lc).isNotEmpty();
	}

	@Test
	public void testDeleteComment() {
		Question q = new Question("Test question 5");
		q.setTopic(topic);
		Question q1 = questionRepository.save(q);
		questionRepository.flush();
		Comment c = new Comment("Test comment 3");
		c.setQuestion(q1);
		Comment c1 = commentRepository.save(c);
		commentRepository.flush();
		int id = c1.getId();
		commentRepository.delete(c1);
		Optional<Comment> oc = commentRepository.findById(id);
		assertThat(oc).isEqualTo(Optional.empty());
	}

}
