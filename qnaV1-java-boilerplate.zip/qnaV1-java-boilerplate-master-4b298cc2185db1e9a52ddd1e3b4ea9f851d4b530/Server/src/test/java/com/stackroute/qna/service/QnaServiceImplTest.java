package com.stackroute.qna.service;

import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.stackroute.qna.domain.Comment;
import com.stackroute.qna.domain.Question;
import com.stackroute.qna.domain.Topic;
import com.stackroute.qna.exception.CommentNotFoundException;
import com.stackroute.qna.exception.QuestionNotFoundException;
import com.stackroute.qna.repository.CommentRepository;
import com.stackroute.qna.repository.QuestionRepository;
import com.stackroute.qna.repository.TopicRepository;

public class QnaServiceImplTest {

	@Mock
	private QuestionRepository questionRepository;

	@Mock
	private CommentRepository commentRepository;

	@Mock
	private TopicRepository topicRepository;

	@InjectMocks
	private transient QnaServiceImpl qnaServiceImpl;

	static transient Topic topic;

	static transient Comment comment;

	static transient Question question;

	private transient Optional<Topic> optTopic;

	private transient Optional<Comment> optComment;

	private transient Optional<Question> optQuestion;

	@Before
	public void setupmock() {
		MockitoAnnotations.initMocks(this);
		
		topic = new Topic(1, "topic1", "topic 1 description");
		
		question = new Question("question 1");
		question.setId(1);
		question.setTopic(topic);
		
		comment = new Comment("comment 1");
		comment.setId(1);
		comment.setQuestion(question);

		optTopic = Optional.of(topic);
		optQuestion = Optional.of(question);
		optComment = Optional.of(comment);
	}

	@Test
	public void testGetAllTopics() {
		List<Topic> topics = new ArrayList<Topic>();
		topics.add(topic);
		Mockito.when(topicRepository.findAll()).thenReturn(topics);
		qnaServiceImpl.getAllTopics();
		Mockito.verify(topicRepository, times(1)).findAll();
	}

	@Test
	public void testGetQuestionsByTopic() throws QuestionNotFoundException {
		List<Question> questions = new ArrayList<Question>();
		questions.add(question);		
		Mockito.when(questionRepository.findByTopicIdOrderByIdDesc(topic.getId())).thenReturn(questions);
		qnaServiceImpl.getQuestionsOnTopic(topic.getId());
		Mockito.verify(questionRepository, times(1)).findByTopicIdOrderByIdDesc(topic.getId());
	}

	@Test
	public void testSaveQuestion() {
		Mockito.when(questionRepository.save(question)).thenReturn(question);
		qnaServiceImpl.saveQuestion(question);		
		Mockito.verify(questionRepository, times(1)).save(question);
	}

	@Test
	public void testDeleteQuestion() throws QuestionNotFoundException {
		Mockito.when(questionRepository.findById(question.getId())).thenReturn(optQuestion);
		doNothing().when(questionRepository).deleteById(question.getId());
		boolean isDeleted = qnaServiceImpl.deleteQuestion(question.getId());
		assertTrue("delete movie success", isDeleted);
		Mockito.verify(questionRepository, times(1)).findById(question.getId());
		Mockito.verify(questionRepository, times(1)).deleteById(question.getId());		
	}

	@Test
	public void testGetCommentsByQuestion() throws CommentNotFoundException  {
		List<Comment> comments = new ArrayList<Comment>();
		comments.add(comment);
		Mockito.when(commentRepository.findByQuestionIdOrderByIdDesc(question.getId())).thenReturn(comments);
		qnaServiceImpl.getCommentOnQuestion(question.getId());
		Mockito.verify(commentRepository, times(1)).findByQuestionIdOrderByIdDesc(question.getId());
	}

	@Test
	public void testSaveComment()  {
		Mockito.when(commentRepository.save(comment)).thenReturn(comment);
		qnaServiceImpl.saveComment(comment);
		Mockito.verify(commentRepository, times(1)).save(comment);
	}

	@Test
	public void testDeleteComment() throws CommentNotFoundException {
		Mockito.when(commentRepository.findById(comment.getId())).thenReturn(optComment);
		doNothing().when(commentRepository).deleteById(comment.getId());
		boolean isDeleted = qnaServiceImpl.deleteComment(comment.getId());
		assertTrue("delete comment success", isDeleted);
		Mockito.verify(commentRepository, times(1)).deleteById(comment.getId());
		Mockito.verify(commentRepository, times(1)).findById(comment.getId());
	}

}
