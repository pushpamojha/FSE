INSERT INTO `qnadb`.`topic` (`id`,`description`,`title`) VALUES (1,'Weather','Topic 1');
INSERT INTO `qnadb`.`topic` (`id`,`description`,`title`) VALUES (2,'Cricket','Topic 2');
INSERT INTO `qnadb`.`topic` (`id`,`description`,`title`) VALUES (3,'Love','Topic 3');
INSERT INTO `qnadb`.`topic` (`id`,`description`,`title`) VALUES (4,'Travel','Topic 4');
INSERT INTO `qnadb`.`topic` (`id`,`description`,`title`) VALUES (5,'Politics','Topic 5');